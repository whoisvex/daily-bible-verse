$ErrorActionPreference = 'Stop'
$framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
$compiler = Join-Path $framework 'csc.exe'
if (-not (Test-Path -LiteralPath $compiler)) { throw 'The Windows .NET Framework compiler is unavailable.' }
$arguments = @(
 ('/win32icon:' + (Join-Path $PSScriptRoot 'source\verse.ico')),
 ('/resource:' + (Join-Path $PSScriptRoot 'source\verse.ico') + ',verse.ico'),
 '/nologo', '/target:winexe', '/platform:anycpu', '/optimize+', '/codepage:65001',
 ('/out:' + (Join-Path $PSScriptRoot 'Daily Verse.exe')),
 ('/reference:' + (Join-Path $framework 'WPF\PresentationFramework.dll')),
 ('/reference:' + (Join-Path $framework 'WPF\PresentationCore.dll')),
 ('/reference:' + (Join-Path $framework 'WPF\WindowsBase.dll')),
 ('/reference:' + (Join-Path $framework 'System.Xaml.dll')),
 ('/reference:' + (Join-Path $framework 'System.Net.Http.dll')),
 ('/reference:' + (Join-Path $framework 'System.Web.Extensions.dll')),
 ('/reference:' + (Join-Path $framework 'System.Windows.Forms.dll')),
 ('/reference:' + (Join-Path $framework 'System.Drawing.dll')),
 ('/reference:' + (Join-Path $framework 'Microsoft.CSharp.dll')),
 (Join-Path $PSScriptRoot 'source\WidgetStorage.cs'),
 (Join-Path $PSScriptRoot 'source\NivFeed.cs'),
 (Join-Path $PSScriptRoot 'source\DailyVerse.cs')
)
& $compiler @arguments
if ($LASTEXITCODE -ne 0) { throw 'Compilation failed.' }
Write-Output 'Built Daily Verse.exe'



