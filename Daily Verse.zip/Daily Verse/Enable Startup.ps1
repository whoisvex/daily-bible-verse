param([switch]$NoLaunch)
$ErrorActionPreference = 'Stop'
$widgetExe = Join-Path $PSScriptRoot 'Daily Verse.exe'
if (-not (Test-Path -LiteralPath $widgetExe)) { throw 'Daily Verse.exe must be beside this script.' }
$startupFolder = [Environment]::GetFolderPath('Startup')
$shortcutFile = Join-Path $startupFolder 'Daily Verse Widget.lnk'
$shortcutShell = New-Object -ComObject WScript.Shell
$shortcut = $shortcutShell.CreateShortcut($shortcutFile)
$shortcut.TargetPath = $widgetExe
$shortcut.Arguments = '--startup'
$shortcut.WorkingDirectory = $PSScriptRoot
$shortcut.Description = 'Show your daily NIV Bible verse on the desktop'
$shortcut.IconLocation = $widgetExe + ',0'
$shortcut.Save()
Write-Output ('Enabled automatic opening: ' + $shortcutFile)
if (-not $NoLaunch) { Start-Process -FilePath $widgetExe }
