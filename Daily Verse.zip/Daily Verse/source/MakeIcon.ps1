Add-Type -AssemblyName System.Drawing
$bitmap = New-Object System.Drawing.Bitmap 64,64
$graphics = [System.Drawing.Graphics]::FromImage($bitmap)
$graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$green = New-Object System.Drawing.SolidBrush ([System.Drawing.ColorTranslator]::FromHtml('#284F40'))
$cream = New-Object System.Drawing.SolidBrush ([System.Drawing.ColorTranslator]::FromHtml('#FFFEFA'))
$gold = New-Object System.Drawing.Pen ([System.Drawing.ColorTranslator]::FromHtml('#C6AF71')),2
$graphics.FillEllipse($green,0,0,63,63)
$left = [System.Drawing.PointF[]]@([System.Drawing.PointF]::new(14,20),[System.Drawing.PointF]::new(31,24),[System.Drawing.PointF]::new(31,47),[System.Drawing.PointF]::new(14,43))
$right = [System.Drawing.PointF[]]@([System.Drawing.PointF]::new(33,24),[System.Drawing.PointF]::new(50,20),[System.Drawing.PointF]::new(50,43),[System.Drawing.PointF]::new(33,47))
$graphics.FillPolygon($cream,$left)
$graphics.FillPolygon($cream,$right)
$graphics.DrawLine($gold,32,13,32,21)
$graphics.DrawLine($gold,28,17,36,17)
$buffer = New-Object System.IO.MemoryStream
$bitmap.Save($buffer,[System.Drawing.Imaging.ImageFormat]::Png)
$png = $buffer.ToArray()
$target = Join-Path $PSScriptRoot 'verse.ico'
$writer = New-Object System.IO.BinaryWriter ([System.IO.File]::Create($target))
$writer.Write([uint16]0); $writer.Write([uint16]1); $writer.Write([uint16]1)
$writer.Write([byte]64); $writer.Write([byte]64); $writer.Write([byte]0); $writer.Write([byte]0)
$writer.Write([uint16]1); $writer.Write([uint16]32); $writer.Write([uint32]$png.Length); $writer.Write([uint32]22)
$writer.Write($png); $writer.Dispose()
$buffer.Dispose(); $graphics.Dispose(); $bitmap.Dispose(); $green.Dispose(); $cream.Dispose(); $gold.Dispose()
