using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Forms=System.Windows.Forms;
namespace DailyVerse {
 public sealed class VerseWindow:Window {
  readonly TextBlock dateText,verseText,referenceText,statusText;
  readonly Button copyButton;
  readonly Border card;
  readonly FrameworkElement header,verseActions,footer;
  readonly ScrollViewer verseScroll;
  bool verseOnly;
  readonly DispatcherTimer dailyTimer,copyTimer,saveTimer;
  readonly bool testing;
  Forms.NotifyIcon tray;
  WidgetPreferences preferences;
  Verse shownVerse;
  DateTime shownDate=DateTime.MinValue,nextFetch=DateTime.MinValue;
  bool fetching,closed,exiting;
  public VerseWindow(bool testMode=false) {
   testing=testMode; Title="Daily Verse Widget";
   WindowStyle=WindowStyle.None; AllowsTransparency=true; Background=Brushes.Transparent;
   ResizeMode=ResizeMode.CanResizeWithGrip; ShowInTaskbar=false; ShowActivated=false;
   MinWidth=320; MinHeight=380; MaxWidth=800; MaxHeight=1000;
   WindowStartupLocation=WindowStartupLocation.Manual;
   preferences=testing?new WidgetPreferences():WidgetStorage.Load();
   var desktop=new Rect(SystemParameters.VirtualScreenLeft,SystemParameters.VirtualScreenTop,SystemParameters.VirtualScreenWidth,SystemParameters.VirtualScreenHeight);
   var place=WidgetStorage.Place(preferences,desktop,SystemParameters.WorkArea);
   Left=place.Left;Top=place.Top;Width=place.Width;Height=place.Height;Topmost=preferences.KeepOnTop;
   FontFamily=new FontFamily("Segoe UI");UseLayoutRounding=true;
   using(var icon=Assembly.GetExecutingAssembly().GetManifestResourceStream("verse.ico"))Icon=BitmapFrame.Create(icon,BitmapCreateOptions.None,BitmapCacheOption.OnLoad);
   var root=(Grid)XamlReader.Parse(Layout);Content=root;
   dateText=(TextBlock)root.FindName("DateLabel");verseText=(TextBlock)root.FindName("VerseLabel");
   referenceText=(TextBlock)root.FindName("ReferenceLabel");statusText=(TextBlock)root.FindName("StatusLabel");
   copyButton=(Button)root.FindName("CopyButton");copyButton.IsEnabled=false;
   card=(Border)root.FindName("VerseCard");header=(FrameworkElement)root.FindName("DragHeader");
   verseActions=(FrameworkElement)root.FindName("VerseActions");footer=(FrameworkElement)root.FindName("Footer");
   verseScroll=(ScrollViewer)root.FindName("VerseScroll");
   SetVerseOnly(preferences.VerseOnly,false);
   root.MouseRightButtonUp+=(s,e)=>{var menu=BuildMenu();menu.PlacementTarget=root;menu.Placement=System.Windows.Controls.Primitives.PlacementMode.MousePoint;menu.IsOpen=true;e.Handled=true;};
   verseText.MouseLeftButtonDown+=(s,e)=>{if(verseOnly){try{DragMove();}catch(InvalidOperationException){}e.Handled=true;}};
   ((TextBlock)root.FindName("CopyrightLabel")).Text=NivFeed.Copyright;
   ((Grid)root.FindName("DragHeader")).MouseLeftButtonDown+=(s,e)=>{
    if(e.OriginalSource is TextBlock||e.OriginalSource==s){try{DragMove();}catch(InvalidOperationException){}}
   };
   ((Button)root.FindName("HideButton")).Click+=(s,e)=>Hide();
   ((Button)root.FindName("MenuButton")).Click+=(s,e)=>{var menu=BuildMenu();menu.PlacementTarget=(Button)s;menu.IsOpen=true;};
   copyTimer=new DispatcherTimer{Interval=TimeSpan.FromSeconds(2)};
   copyTimer.Tick+=(s,e)=>{copyButton.Content="Copy verse";copyTimer.Stop();};
   copyButton.Click+=(s,e)=>CopyVerse();
   ((System.Windows.Documents.Hyperlink)root.FindName("SourceLink")).RequestNavigate+=(s,e)=>{
    var link=shownVerse==null?"https://www.biblegateway.com/":shownVerse.Link;
    try{System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(link){UseShellExecute=true});}
    catch{statusText.Text="Could not open your browser.";}e.Handled=true;
   };
   saveTimer=new DispatcherTimer{Interval=TimeSpan.FromMilliseconds(600)};
   saveTimer.Tick+=(s,e)=>{saveTimer.Stop();SavePosition();};
   LocationChanged+=(s,e)=>QueueSave();SizeChanged+=(s,e)=>QueueSave();
   dailyTimer=new DispatcherTimer();dailyTimer.Tick+=(s,e)=>RefreshDay();
   Activated+=(s,e)=>RefreshDay();
   Loaded+=async(s,e)=>{if(!testing){CreateTray();await FetchVerseAsync();}};
   Closing+=(s,e)=>{
    if(!testing&&!exiting){e.Cancel=true;Hide();return;}SavePosition();
   };
   Closed+=(s,e)=>{closed=true;dailyTimer.Stop();copyTimer.Stop();saveTimer.Stop();if(tray!=null)tray.Dispose();};
   var saved=testing?null:NivFeed.Cached();
   if(saved!=null)ShowVerse(saved,true);
   else{verseText.Text="Connecting to today\u2019s NIV verse\u2026";referenceText.Text="New International Version";statusText.Text="Internet needed for new daily verses";}
   RefreshDay();dailyTimer.Start();
  }
  internal void SetVerseOnly(bool enabled,bool persist=true){
   verseOnly=enabled;preferences.VerseOnly=enabled;
   var visibility=enabled?Visibility.Collapsed:Visibility.Visible;
   header.Visibility=visibility;verseActions.Visibility=visibility;footer.Visibility=visibility;
   card.Background=enabled?null:(Brush)new BrushConverter().ConvertFromString("#FFFEF8");
   card.BorderBrush=enabled?Brushes.Transparent:(Brush)new BrushConverter().ConvertFromString("#DBE1D0");
   card.Effect=enabled?null:new System.Windows.Media.Effects.DropShadowEffect{BlurRadius=12,ShadowDepth=2,Opacity=0.2};
   verseText.Foreground=enabled?Brushes.White:(Brush)new BrushConverter().ConvertFromString("#293E2F");
   verseText.Effect=enabled?new System.Windows.Media.Effects.DropShadowEffect{Color=Colors.Black,BlurRadius=5,ShadowDepth=1,Opacity=0.95}:null;
   verseScroll.Margin=enabled?new Thickness(0):new Thickness(0,0,0,14);
   verseScroll.VerticalScrollBarVisibility=enabled?ScrollBarVisibility.Hidden:ScrollBarVisibility.Auto;
   ResizeMode=enabled?ResizeMode.CanResize:ResizeMode.CanResizeWithGrip;
   UpdateVerseTooltip();
   if(persist)SavePosition();
  }
  void UpdateVerseTooltip(){
   verseText.ToolTip=(shownVerse==null?"NIV verse":shownVerse.Reference+" (NIV)")+"\n"+statusText.Text
    +"\n\nPowered by BibleGateway.com\n"+NivFeed.Copyright
    +(verseOnly?"\n\nDrag the verse to move it. Right-click for options.":"");
  }
  void ShowVerseDetails(){
   MessageBox.Show(this,(shownVerse==null?"NIV verse":shownVerse.Reference+" (NIV)")+"\n"+statusText.Text
    +"\n\nPowered by BibleGateway.com\n"+NivFeed.Copyright,"Verse details and source",MessageBoxButton.OK,MessageBoxImage.Information);
  }
  void QueueSave(){if(!testing&&IsLoaded){saveTimer.Stop();saveTimer.Start();}}
  void SavePosition(){
   if(testing)return;
   preferences.Left=Left;preferences.Top=Top;preferences.Width=Width;preferences.Height=Height;preferences.KeepOnTop=Topmost;WidgetStorage.Save(preferences);
  }
  void CopyVerse(){
   if(shownVerse==null)return;
   try{Clipboard.SetText(NivFeed.ClipboardText(shownVerse));copyButton.Content="Copied!";copyTimer.Stop();copyTimer.Start();}
   catch{statusText.Text="Clipboard busy. Please try again.";}
  }
  MenuItem Item(string label,Action action){var item=new MenuItem{Header=label};item.Click+=(s,e)=>action();return item;}
  ContextMenu BuildMenu(){
   var menu=new ContextMenu();
   var minimal=new MenuItem{Header="Verse only",IsCheckable=true,IsChecked=verseOnly};
   minimal.Click+=(s,e)=>SetVerseOnly(minimal.IsChecked);menu.Items.Add(minimal);
   menu.Items.Add(new Separator());
   var onTop=new MenuItem{Header="Keep above other windows",IsCheckable=true,IsChecked=Topmost};
   onTop.Click+=(s,e)=>{Topmost=onTop.IsChecked;SavePosition();};menu.Items.Add(onTop);
   var startup=new MenuItem{Header="Open when Windows starts",IsCheckable=true,IsChecked=WidgetStartup.Enabled};
   startup.Click+=(s,e)=>ChangeStartup(startup.IsChecked);menu.Items.Add(startup);
   menu.Items.Add(Item("Verse details and source",ShowVerseDetails));
   menu.Items.Add(Item("Copy verse",CopyVerse));
   menu.Items.Add(Item("Refresh NIV verse",()=>{nextFetch=DateTime.MinValue;var pending=FetchVerseAsync();}));
   menu.Items.Add(new Separator());menu.Items.Add(Item("Hide widget (keep running)",()=>Hide()));menu.Items.Add(Item("Exit Daily Verse",ExitWidget));return menu;
  }
  void ChangeStartup(bool enabled){
   try{WidgetStartup.SetEnabled(enabled);statusText.Text=enabled?"Opens automatically when you sign in":"Automatic opening is off";}
   catch{MessageBox.Show(this,"Windows could not change automatic opening. Please run the setup script included with the widget.","Daily Verse Widget",MessageBoxButton.OK,MessageBoxImage.Information);}
  }
  void CreateTray(){
   tray=new Forms.NotifyIcon{Text="Daily Verse - NIV",Visible=true};
   using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("verse.ico"))tray.Icon=new System.Drawing.Icon(stream);
   var menu=new Forms.ContextMenuStrip();menu.Items.Add("Show widget",null,(s,e)=>RestoreWidget());
   var minimalItem=new Forms.ToolStripMenuItem("Verse only"){CheckOnClick=true,Checked=verseOnly};
   minimalItem.Click+=(s,e)=>SetVerseOnly(minimalItem.Checked);menu.Items.Add(minimalItem);
   menu.Items.Add("Verse details and source",null,(s,e)=>ShowVerseDetails());
   var topItem=new Forms.ToolStripMenuItem("Keep above other windows"){CheckOnClick=true,Checked=Topmost};
   topItem.Click+=(s,e)=>{Topmost=topItem.Checked;SavePosition();};menu.Items.Add(topItem);
   var startupItem=new Forms.ToolStripMenuItem("Open when Windows starts"){CheckOnClick=true,Checked=WidgetStartup.Enabled};
   startupItem.Click+=(s,e)=>ChangeStartup(startupItem.Checked);menu.Items.Add(startupItem);
   menu.Items.Add("Refresh NIV verse",null,(s,e)=>{nextFetch=DateTime.MinValue;var pending=FetchVerseAsync();});
   menu.Items.Add(new Forms.ToolStripSeparator());menu.Items.Add("Exit Daily Verse",null,(s,e)=>ExitWidget());
   menu.Opening+=(s,e)=>{minimalItem.Checked=verseOnly;topItem.Checked=Topmost;startupItem.Checked=WidgetStartup.Enabled;};
   tray.ContextMenuStrip=menu;tray.MouseClick+=(s,e)=>{if(e.Button==Forms.MouseButtons.Left)RestoreWidget();};
  }
  void RestoreWidget(){Show();WindowState=WindowState.Normal;Activate();}
  void ExitWidget(){exiting=true;Close();}
  void RefreshDay(){DisplayDay(DateTime.Now);}
  internal void DisplayDay(DateTime now){
   if(now.Date!=shownDate){shownDate=now.Date;dateText.Text=now.ToString("dddd, MMMM d",CultureInfo.CurrentCulture);nextFetch=DateTime.MinValue;}
   dailyTimer.Interval=NivFeed.RefreshInterval(now);
   if(!testing&&IsLoaded&&!fetching&&now>=nextFetch){var pending=FetchVerseAsync();}
  }
  void ShowVerse(Verse verse,bool saved){
   shownVerse=verse;verseText.Text=verse.Text;referenceText.Text=verse.Reference+" (NIV)";
   verseText.FontSize=verse.Text.Length>180?21:24;copyButton.IsEnabled=true;copyButton.Content="Copy verse";
   statusText.Text=(saved?"Saved":"Daily verse")+" \u00b7 "+verse.Date.ToString("MMM d",CultureInfo.CurrentCulture)+(saved?" \u00b7 Connecting\u2026":" \u00b7 Updates automatically");
   UpdateVerseTooltip();
  }
  async System.Threading.Tasks.Task FetchVerseAsync(){
   if(fetching||closed)return;fetching=true;nextFetch=DateTime.Now.AddMinutes(30);
   try{var verse=await NivFeed.FetchAsync();if(!closed)ShowVerse(verse,false);}
   catch{if(!closed){nextFetch=DateTime.Now.AddMinutes(5);ShowOffline();}}
   finally{fetching=false;}
  }
  void ShowOffline(){
   if(shownVerse==null){verseText.Text="Connect to the internet to load today\u2019s NIV verse.";referenceText.Text="Waiting for a connection";copyButton.IsEnabled=false;statusText.Text="Could not connect. Retrying automatically.";}
   else statusText.Text="Offline \u00b7 Saved NIV verse from "+shownVerse.Date.ToString("MMM d",CultureInfo.CurrentCulture);
   UpdateVerseTooltip();
  }
  internal void TestDisplay(){
   if(!Topmost||WindowStyle!=WindowStyle.None||ShowInTaskbar)throw new Exception("Widget defaults failed");
   DisplayDay(new DateTime(2026,12,31,23,59,59));DisplayDay(new DateTime(2027,1,1,0,0,1));
   if(shownDate.Year!=2027)throw new Exception("Midnight rollover failed");
   ShowOffline();if(copyButton.IsEnabled)throw new Exception("Empty offline state failed");
   ShowVerse(NivFeed.Parse(NivFeed.Sample),true);ShowOffline();
   if(!statusText.Text.Contains("Saved NIV")||!referenceText.Text.Contains("(NIV)")||!copyButton.IsEnabled)throw new Exception("Saved NIV state failed");
   SetVerseOnly(true,false);
   if(header.Visibility!=Visibility.Collapsed||verseActions.Visibility!=Visibility.Collapsed||footer.Visibility!=Visibility.Collapsed||card.Background!=null)throw new Exception("Verse-only visibility failed");
   if(!((MenuItem)BuildMenu().Items[0]).IsChecked||!verseText.ToolTip.ToString().Contains(NivFeed.Copyright))throw new Exception("Verse-only controls or source access failed");
   SetVerseOnly(false,false);
   if(header.Visibility!=Visibility.Visible||footer.Visibility!=Visibility.Visible||card.Background==null)throw new Exception("Full view restoration failed");
   RefreshDay();
  }
  internal void PreviewVerse(Verse verse){ShowVerse(verse,false);}
  internal void WritePreview(string path,double width,double height){
   var root=(Grid)Content;root.Measure(new Size(width,height));root.Arrange(new Rect(0,0,width,height));root.UpdateLayout();
   if(verseText.ActualHeight<=0||(!verseOnly&&(referenceText.ActualHeight<=0||copyButton.ActualHeight<=0)))throw new Exception("Invisible widget content");
   var image=new RenderTargetBitmap((int)width,(int)height,96,96,PixelFormats.Pbgra32);image.Render(root);
   var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(image));using(var file=File.Create(path))encoder.Save(file);
  }
  const string Layout=@"
<Grid xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'>
 <Grid.Resources>
  <Style TargetType='Button'>
   <Setter Property='Background' Value='#E8EDDF'/><Setter Property='Foreground' Value='#35513F'/><Setter Property='Cursor' Value='Hand'/>
   <Setter Property='Padding' Value='9,5'/><Setter Property='FontSize' Value='12'/>
   <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='Button'>
    <Border x:Name='Frame' Background='{TemplateBinding Background}' CornerRadius='6' Padding='{TemplateBinding Padding}'><ContentPresenter HorizontalAlignment='Center' VerticalAlignment='Center'/></Border>
    <ControlTemplate.Triggers>
     <Trigger Property='IsMouseOver' Value='True'><Setter TargetName='Frame' Property='Background' Value='#DCE4D0'/></Trigger>
     <Trigger Property='IsKeyboardFocused' Value='True'><Setter TargetName='Frame' Property='BorderThickness' Value='1'/><Setter TargetName='Frame' Property='BorderBrush' Value='#8B7950'/></Trigger>
     <Trigger Property='IsEnabled' Value='False'><Setter TargetName='Frame' Property='Opacity' Value='0.5'/></Trigger>
    </ControlTemplate.Triggers>
   </ControlTemplate></Setter.Value></Setter>
  </Style>
 </Grid.Resources>
 <Border x:Name='VerseCard' Margin='9' Background='#FFFEF8' CornerRadius='16' BorderBrush='#DBE1D0' BorderThickness='1'>
  <Border.Effect><DropShadowEffect BlurRadius='12' ShadowDepth='2' Opacity='0.2'/></Border.Effect>
  <Grid Margin='20,16,20,16'>
   <Grid.RowDefinitions><RowDefinition Height='Auto'/><RowDefinition Height='*'/><RowDefinition Height='Auto'/><RowDefinition Height='Auto'/></Grid.RowDefinitions>
   <Grid x:Name='DragHeader' Background='Transparent' Cursor='SizeAll' Margin='0,0,0,16'>
    <Grid.ColumnDefinitions><ColumnDefinition Width='*'/><ColumnDefinition Width='Auto'/><ColumnDefinition Width='Auto'/></Grid.ColumnDefinitions>
    <StackPanel><TextBlock Text='DAILY VERSE  /  NIV' FontSize='11' FontWeight='SemiBold' Foreground='#526C50'/><TextBlock x:Name='DateLabel' FontSize='11' Foreground='#747F6C' Margin='0,4,0,0'/></StackPanel>
    <Button x:Name='MenuButton' Grid.Column='1' Content='&#x22EF;' FontSize='17' Margin='6,0,4,0' Padding='7,0' VerticalAlignment='Top' ToolTip='Widget options' Cursor='Hand'/>
    <Button x:Name='HideButton' Grid.Column='2' Content='&#x00D7;' FontSize='16' Padding='7,0' VerticalAlignment='Top' ToolTip='Hide widget; click its tray icon to show it again' Cursor='Hand'/>
   </Grid>
   <ScrollViewer x:Name='VerseScroll' Grid.Row='1' VerticalScrollBarVisibility='Auto' HorizontalScrollBarVisibility='Disabled' Margin='0,0,0,14' Padding='0,0,6,0'>
    <TextBlock x:Name='VerseLabel' FontFamily='Georgia' FontSize='24' TextWrapping='Wrap' Foreground='#293E2F' VerticalAlignment='Center'/>
   </ScrollViewer>
   <Grid x:Name='VerseActions' Grid.Row='2' Margin='0,0,0,15'>
    <Grid.ColumnDefinitions><ColumnDefinition Width='*'/><ColumnDefinition Width='Auto'/></Grid.ColumnDefinitions>
    <TextBlock x:Name='ReferenceLabel' FontSize='14' Foreground='#355A43' FontWeight='SemiBold' VerticalAlignment='Center' TextWrapping='Wrap' Margin='0,0,6,0'/>
    <Button x:Name='CopyButton' Grid.Column='1' Content='Copy verse' VerticalAlignment='Center' ToolTip='Copy verse with source and attribution'/>
   </Grid>
   <StackPanel x:Name='Footer' Grid.Row='3'>
    <Border Height='1' Background='#E6E8DF' Margin='0,0,0,10'/>
    <TextBlock FontSize='10.5' Margin='0,0,0,5'><Hyperlink x:Name='SourceLink' NavigateUri='https://www.biblegateway.com/' Foreground='#55704E'>Powered by BibleGateway.com</Hyperlink></TextBlock>
    <TextBlock x:Name='CopyrightLabel' FontSize='9' Foreground='#78806F' TextWrapping='Wrap' Margin='0,0,0,7'/>
    <TextBlock x:Name='StatusLabel' FontSize='10' Foreground='#6B775E' TextWrapping='Wrap' AutomationProperties.LiveSetting='Polite'/>
   </StackPanel>
  </Grid>
 </Border>
</Grid>";
 }
 public static class Program {
  [DllImport("user32.dll",CharSet=CharSet.Unicode)]static extern IntPtr FindWindow(string className,string title);
  [DllImport("user32.dll")]static extern bool ShowWindow(IntPtr window,int command);
  [DllImport("user32.dll")]static extern bool SetForegroundWindow(IntPtr window);
  [STAThread]public static int Main(string[] args){
   bool test=args.Contains("--self-test");
   try{
    if(test){
     NivFeed.Test();WidgetStartup.Test();var app=new Application();var window=new VerseWindow(true);window.TestDisplay();
     int previewIndex=Array.IndexOf(args,"--preview-json");
     if(previewIndex>=0&&previewIndex+1<args.Length)window.PreviewVerse(NivFeed.Parse(File.ReadAllText(args[previewIndex+1])));
     if(args.Contains("--check-feed"))window.PreviewVerse(NivFeed.FetchAsync().GetAwaiter().GetResult());
     window.WritePreview(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Preview.png"),400,480);
     window.WritePreview(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Preview-small.png"),320,380);
     window.SetVerseOnly(true,false);
     window.WritePreview(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Preview-verse-only.png"),400,480);
     window.WritePreview(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Preview-verse-only-small.png"),320,380);
     window.SetVerseOnly(false,false);
     File.WriteAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"test-results.txt"),"PASS: verse-only mode; full view restoration; right-click options; source attribution access; mode persistence and old settings compatibility; widget defaults; saved position; offscreen recovery; NIV validation; midnight rollover; offline display; normal, small, and verse-only layouts.\r\n",Encoding.UTF8);
     window.Close();return 0;
    }
    bool created;
    using(var mutex=new System.Threading.Mutex(true,"Local\\DailyVerseDesktopWidget",out created)){
     if(!created){var handle=FindWindow(null,"Daily Verse Widget");if(handle!=IntPtr.Zero){ShowWindow(handle,9);SetForegroundWindow(handle);}return 0;}
     try{var app=new Application();app.Run(new VerseWindow());}finally{mutex.ReleaseMutex();}
    }
    return 0;
   }catch(Exception ex){
    if(test)File.WriteAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"test-results.txt"),"FAIL: "+ex);
    else MessageBox.Show("Daily Verse could not open.\n\n"+ex.Message,"Daily Verse Widget",MessageBoxButton.OK,MessageBoxImage.Information);
    return 1;
   }
  }
 }
}
