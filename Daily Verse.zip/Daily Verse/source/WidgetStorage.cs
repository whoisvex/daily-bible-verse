using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows;
namespace DailyVerse {
 public sealed class WidgetPreferences {
  public double Left=-100000, Top=-100000, Width=400, Height=480;
  public bool KeepOnTop=true;
  public bool VerseOnly=false;
 }
 public static class WidgetStorage {
  public static string SettingsPath { get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Daily Verse.widget.json"); } }
  public static WidgetPreferences Load() {
   try { return new JavaScriptSerializer().Deserialize<WidgetPreferences>(File.ReadAllText(SettingsPath)) ?? new WidgetPreferences(); } catch { return new WidgetPreferences(); }
  }
  public static void Save(WidgetPreferences settings) {
   try { File.WriteAllText(SettingsPath,new JavaScriptSerializer().Serialize(settings),Encoding.UTF8); } catch (IOException) {} catch (UnauthorizedAccessException) {}
  }
  public static Rect Place(WidgetPreferences settings,Rect desktop,Rect work) {
   double width=Double.IsNaN(settings.Width)||Double.IsInfinity(settings.Width)?400:Math.Max(320,Math.Min(800,settings.Width));
   double height=Double.IsNaN(settings.Height)||Double.IsInfinity(settings.Height)?480:Math.Max(380,Math.Min(1000,settings.Height));
   double left=settings.Left, top=settings.Top;
   if (Double.IsNaN(left)||Double.IsInfinity(left)||Double.IsNaN(top)||Double.IsInfinity(top)||left+width<desktop.Left+60||left>desktop.Right-60||top<desktop.Top||top>desktop.Bottom-60) {
    left=work.Right-width-18; top=work.Top+18;
   }
   return new Rect(left,top,width,height);
  }
 }
 public static class WidgetStartup {
  public static string ShortcutPath { get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Startup),"Daily Verse Widget.lnk"); } }
  public static bool Enabled { get { return File.Exists(ShortcutPath); } }
  public static void SetEnabled(bool enabled) {
   if (!enabled) { if(File.Exists(ShortcutPath))File.Delete(ShortcutPath); return; }
   object shellObject=null, shortcutObject=null;
   try {
    shellObject=Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell"));
    dynamic shell=shellObject;
    shortcutObject=shell.CreateShortcut(ShortcutPath);
    dynamic shortcut=shortcutObject;
    shortcut.TargetPath=Assembly.GetExecutingAssembly().Location;
    shortcut.Arguments="--startup"; shortcut.WorkingDirectory=AppDomain.CurrentDomain.BaseDirectory;
    shortcut.Description="Show your daily NIV Bible verse on the desktop";
    shortcut.IconLocation=Assembly.GetExecutingAssembly().Location+",0"; shortcut.Save();
   } finally {
    if(shortcutObject!=null)Marshal.FinalReleaseComObject(shortcutObject);
    if(shellObject!=null)Marshal.FinalReleaseComObject(shellObject);
   }
  }
  public static void Test() {
   var area=new Rect(0,0,1920,1080);
   var first=WidgetStorage.Place(new WidgetPreferences(),area,area);
   if(first.X<0||first.Right>area.Right||first.Y<0)throw new Exception("Default placement");
   var off=WidgetStorage.Place(new WidgetPreferences{Left=99999,Top=99999},area,area);
   if(off.Right>area.Right||off.Top>area.Bottom)throw new Exception("Offscreen recovery");
   var saved=WidgetStorage.Place(new WidgetPreferences{Left=200,Top=150,Width=410,Height=500},area,area);
   if(saved.Left!=200||saved.Top!=150||saved.Width!=410)throw new Exception("Remembered placement");
   if(!new WidgetPreferences().KeepOnTop)throw new Exception("Always-on-top default");
   var serializer=new JavaScriptSerializer();
   var roundtrip=serializer.Deserialize<WidgetPreferences>(serializer.Serialize(new WidgetPreferences{VerseOnly=true}));
   if(!roundtrip.VerseOnly)throw new Exception("Verse-only persistence");
   var older=serializer.Deserialize<WidgetPreferences>("{\"KeepOnTop\":true}");
   if(older.VerseOnly)throw new Exception("Old settings compatibility");
  }
 }
}