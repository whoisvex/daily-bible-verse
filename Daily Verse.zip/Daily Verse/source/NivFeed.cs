using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace DailyVerse {
    public sealed class Verse {
        public string Reference;
        public string Text;
        public DateTime Date;
        public string Link { get { return "https://www.biblegateway.com/passage/?search=" + Uri.EscapeDataString(Reference) + "&version=NIV"; } }
    }
    public static class NivFeed {
        public const string Endpoint = "https://www.biblegateway.com/votd/get/?format=json&version=NIV";
        public const string Copyright = "Scripture taken from the Holy Bible, NEW INTERNATIONAL VERSION\u00ae, NIV\u00ae. Copyright \u00a9 1973, 1978, 1984, 2011 by Biblica, Inc.\u00ae Used by permission. All rights reserved worldwide.";
        static readonly HttpClient Client = CreateClient();
        static HttpClient CreateClient() {
            ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
            var client = new HttpClient { Timeout = TimeSpan.FromSeconds(20) };
            client.DefaultRequestHeaders.UserAgent.ParseAdd("DailyVerseDesktop/2.0");
            client.DefaultRequestHeaders.Accept.ParseAdd("application/json");
            return client;
        }
        public static string CachePath { get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Daily Verse.niv-cache.json"); } }
        static string Field(Dictionary<string, object> data, string key) {
            object value;
            return data.TryGetValue(key, out value) ? Convert.ToString(value, CultureInfo.InvariantCulture) : "";
        }
        public static string PlainText(string value) {
            return WebUtility.HtmlDecode(Regex.Replace(value, "<[^>]*>", "")).Trim();
        }
        public static Verse Parse(string json) {
            if (String.IsNullOrWhiteSpace(json) || json.Length > 1000000) throw new InvalidDataException("Invalid verse response.");
            var root = new JavaScriptSerializer().DeserializeObject(json) as Dictionary<string, object>;
            object item;
            if (root == null || !root.TryGetValue("votd", out item)) throw new InvalidDataException("Missing daily verse.");
            var data = item as Dictionary<string, object>;
            if (data == null || Field(data, "version_id") != "NIV") throw new InvalidDataException("The feed did not return NIV.");
            var verse = new Verse {
                Reference = PlainText(Field(data, "display_ref")),
                Text = PlainText(Field(data, "text")),
                Date = new DateTime(Int32.Parse(Field(data, "year")), Int32.Parse(Field(data, "month")), Int32.Parse(Field(data, "day")))
            };
            if (String.IsNullOrWhiteSpace(verse.Reference) || String.IsNullOrWhiteSpace(verse.Text))
                throw new InvalidDataException("The verse is empty.");
            return verse;
        }
        public static async Task<Verse> FetchAsync() {
            string json = await Client.GetStringAsync(Endpoint).ConfigureAwait(false);
            var verse = Parse(json);
            // Save only the latest response for this user's offline display, never an archive.
            try { File.WriteAllText(CachePath, json, Encoding.UTF8); } catch (IOException) {} catch (UnauthorizedAccessException) {}
            return verse;
        }
        public static Verse Cached() {
            try { return Parse(File.ReadAllText(CachePath, Encoding.UTF8)); } catch { return null; }
        }
        public static string ClipboardText(Verse verse) { return verse.Text + Environment.NewLine + "\u2014 " + verse.Reference + " (NIV)" + Environment.NewLine + "Powered by BibleGateway.com" + Environment.NewLine + verse.Link + Environment.NewLine + Copyright; }
        public static TimeSpan RefreshInterval(DateTime now) {
            return TimeSpan.FromMilliseconds(Math.Max(100, Math.Min(15000, (now.Date.AddDays(1) - now).TotalMilliseconds + 30)));
        }
        public const string Sample = "{\"votd\":{\"display_ref\":\"Example reference\",\"text\":\"Example text &amp; entity. Not Scripture.\",\"version_id\":\"NIV\",\"year\":\"2026\",\"month\":\"10\",\"day\":\"27\"}}";
        public static void Test() {
            var parsed = Parse(Sample);
            if (parsed.Text != "Example text & entity. Not Scripture.") throw new Exception("Entity decoding failed");
            if (PlainText("<b>Safe</b> &amp; plain") != "Safe & plain") throw new Exception("HTML stripping failed");
            if (!ClipboardText(parsed).Contains("(NIV)") || !ClipboardText(parsed).Contains("Powered by BibleGateway.com")) throw new Exception("Copy attribution failed");
            string[] invalid = {"{}", "not json", Sample.Replace("\"NIV\"", "\"OTHER\""), Sample.Replace("Example reference", ""), Sample.Replace("\"day\":\"27\"", "\"day\":\"40\"")};
            foreach (var item in invalid) {
                bool rejected = false;
                try { Parse(item); } catch { rejected = true; }
                if (!rejected) throw new Exception("Invalid feed accepted");
            }
            if (RefreshInterval(new DateTime(2026,12,31,23,59,59)).TotalMilliseconds > 1100) throw new Exception("Midnight scheduling failed");
        }
    }
}
